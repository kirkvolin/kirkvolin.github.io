TEAM = 'EGR314/Team310/'
TOPIC_HB=TEAM+'Connection Pulse'
TOPIC_PUB = TEAM+'PUB'
TOPIC_SUB = TEAM+'SUB'
TOPIC_SPEED = TEAM+'Speed'
TOPIC_SCREENSTATUS = TEAM+'Display Mode'
TOPIC_ERRORADDRESS = TEAM+'Error Address'
TOPIC_ERRORCODE = TEAM+'Error Code'
MQTT_SERVER = '52.25.206.167'
MQTT_USER='student'
MQTT_PASSWORD='egr3x4'

## Home WiFi
#WIFI_SSID = 'Volin'
#WIFI_PASSWORD='dopehope'

## Hotspot
# WIFI_SSID = 'Hotdogs'
# WIFI_PASSWORD='Hotdog12'


# Peralta Wifi
WIFI_SSID = 'photon'
WIFI_PASSWORD='particle'

## Dom Wifi
# WIFI_SSID = 'Potat Adfree'
# WIFI_PASSWORD='Puppydog'
