import ssl
from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import wifi_led, blue_led, config
import uasyncio as asyncio
from config import *
from machine import UART, Pin

led_pins = [48,21,47,45]
leds = [Pin(pin, Pin.OUT) for pin in led_pins]

# Function to turn on LEDs sequentially to indicate code processing
async def indicate_processing():
    count = 0
    max_count = 3  

    while count < max_count:
        for led in leds:
            led.value(1)  # Turn LED ON
            await asyncio.sleep(0.05)
            led.value(0)  # Turn LED OFF
            await asyncio.sleep(0.05)

        count += 1  

led_21 = Pin(21, Pin.OUT)
led_47 = Pin(47, Pin.OUT)
led_48 = Pin(48, Pin.OUT)
led_45 = Pin(45, Pin.OUT)

# Flash diagonals like / \ / \
async def flash_x():
    for _ in range(3):
        # Flash the first diagonal: 21 <-> 45
        led_21.value(1)
        led_45.value(1)
        await asyncio.sleep(0.075)
        led_21.value(0)
        led_45.value(0)
        await asyncio.sleep(0.075)

        # Flash the second diagonal: 47 <-> 48
        led_47.value(1)
        led_48.value(1)
        await asyncio.sleep(0.075)
        led_47.value(0)
        led_48.value(0)
        await asyncio.sleep(0.075)

async def flash_led(led, times=3, delay=0.1):
    for _ in range(times):
        led.value(1)  # Turn LED ON
        await asyncio.sleep(delay)
        led.value(0)  # Turn LED OFF
        await asyncio.sleep(delay)

#### MQTT Protocol
MAXTX = 4

uart = UART(1, baudrate=9600, tx=43, rx=44, bits=8, parity=None)
print('ESP Starting...')
asyncio.create_task(indicate_processing())

# Subscription callback
def sub_cb(topic, msg, retained):
    print(f'Topic: "{topic.decode()}" Message: "{msg.decode()}" Retained: {retained}')
    asyncio.create_task(process_mqtt_message(msg))

async def wifi_han(state):
    wifi_led(not state)
    print('Wifi is ', 'up' if state else 'down')
    asyncio.create_task(flash_led(led_45))
    await asyncio.sleep(1)

async def conn_han(client):
    await client.subscribe(TOPIC_SUB, 1)

async def main(client):

    try:
        await client.connect()
        uart.write(b'AZKHW1YB')
    except OSError:
        print('Connection failed.')
        uart.write(b'AZKHW0YB')
        return

    asyncio.create_task(process_rx())
    n = 0
    while True:
        await asyncio.sleep(10)
        print('publish', n)
        await client.publish(TOPIC_HB, '{}'.format(n, client.REPUB_COUNT), qos=1)
        n += 1

# MQTT Configuration
config['server'] = MQTT_SERVER
config['ssid'] = WIFI_SSID
config['wifi_pw'] = WIFI_PASSWORD

config['ssl'] = True
with open('certs/student_key.pem', 'rb') as f:
    key_data = f.read()
with open('certs/student_crt.pem', 'rb') as f:
    cert_data = f.read()
with open('certs/ca_crt.pem', 'rb') as f:
    ca_data = f.read()
ssl_params = {
    "cert": cert_data,
    "key": key_data,
    "cadata": ca_data,
    "server_hostname": MQTT_SERVER,
    "cert_reqs": ssl.CERT_REQUIRED
}
config["ssl_params"] = ssl_params
config["time_server"] = MQTT_SERVER
config["time_server_timeout"] = 10

config['subs_cb'] = sub_cb
config['wifi_coro'] = wifi_han
config['connect_coro'] = conn_han
config['clean'] = True
config['user'] = MQTT_USER
config["password"] = MQTT_PASSWORD

# Set up client
MQTTClient.DEBUG = True
client = MQTTClient(config)

##### Message Handling

MAX_MESSAGE_LEN = 9
team = [b'H', b'N', b'E', b'K', b'D']
MQTT_ID = b'K'
BROADCAST_ID = b'X'
speed_type = b'V'
screen_state = b'T'
error_type = b'F' 
reset_type = b'R'
HMI_ID = b'H'
UART_PREFIX = b'AZ'
UART_SUFFIX = b'YB'

## ERROR CODES:
# 0: Invalid Sender ID
# 1: Invalid Receiver ID
# 2: Unknown Address Received
# 3: Unexpected Message Sent to MQTT ID
# 4: Unknown Error - Check Terminal for Further Details
# 5: Unexpected Message Sent to Broadcast ID
# 6: Max Message Length Exceeded With Prefix Detected
# 7: Max Message Length Exceeded Without Prefix Detected
# 8: Invalid Message Received Over MQTT
# 9: Unknown Error Processing MQTT Message - Check Terminal for further Details
# A: Invalid Speed Received

led = Pin(2, Pin.OUT)

async def handle_message(message):
    print('ESP: handling message:', message)

    try:
        if message[3:4] == MQTT_ID:  
            if message[4:5] == speed_type:
                
                data = int(message[5:7].decode())

                print(data)
                if data < 100:
                    print(f"Speed value received: {data}")
                    HMI_message = bytearray(message)
                    HMI_message[3] = ord(HMI_ID)
                    print(f"Sending over UART: {HMI_message}")
                    uart.write(bytes(HMI_message))  
                    await client.publish(TOPIC_SPEED, str(data)+" Inches/Second")  

                else:
                    print('Speed value out of expected range')
                    uart.write(b'AZKXFAYB')
                    asyncio.create_task(flash_x())

            elif message[4:5] == screen_state:
                screen_status = int(message[5:6].decode())
                print(f"Screen state received: {screen_status}")
                
                if screen_status == 0:
                    await client.publish(TOPIC_SCREENSTATUS, 'Graphic Display')  
                
                elif screen_status == 1:
                    await client.publish(TOPIC_SCREENSTATUS, 'Data Log')  

                else:
                    print("Invalid screen state message received.")
            else:
                print("Message sent to MQTT with unexpected type")
                uart.write(b'AZKXF3YB')
                asyncio.create_task(flash_x())

        elif message[3:4] == BROADCAST_ID:
            if message[4:5] == error_type:
                error_address = message[2:3]
                error_code = message[5:6]
                print(f"Error Address: {bytes(error_address).decode('utf-8')}, "
                        f"Error Type: {bytes(error_code).decode('utf-8')}")
                await client.publish(TOPIC_ERRORADDRESS, bytes(error_address).decode('utf-8')) 
                await client.publish(TOPIC_ERRORCODE, bytes(error_code).decode('utf-8')) 

            elif message[4:5] == reset_type:
                print("Reset messages looped. Trashing.")
                
            else:
                print("Message sent to broadcast ID with unexpected type")
                uart.write(b'AZKXF5YB')
                asyncio.create_task(flash_x())

        elif message[3:4] in team:
            destination = message[3:4]
            print(f"Resending. Message meant for: {bytes(destination).decode('utf-8')}")
            print(f"Sending over UART: {message}")
            uart.write(message)

    except Exception as e:
        print(f"Unknown error handling message: {e}")
        uart.write(b'AZKXF4YB')
        asyncio.create_task(flash_x())

async def process_rx():
    stream = b''
    message = b''
    receiving_message = False
    
    while True:
        c = uart.read(1)

        # Reset stream if it's filled with junk before detecting a valid message
        if len(stream) >= MAX_MESSAGE_LEN and not receiving_message:
            print('ESP: Max message length exceeded, no prefix detected')
            uart.write(b'AZKXF7YB')
            asyncio.create_task(flash_x())
            stream = b''
            continue

        if c is not None:
            stream += c

            # Detect message start
            if not receiving_message and stream[-2:] == UART_PREFIX:
                print('ESP: Message start detected')
                message = b'A'  # Reset and start fresh with the prefix
                receiving_message = True

            # Only process bytes if receiving a message
            if receiving_message:
                message += c

                if len(message) == 3:
                    print(f"Checking sender: {message[2:3]} against team: {team}")
                    if message[2:3] not in team:
                        print(f"ESP: sender not in team -> {message[2:3]} (expected one of {team})")
                        uart.write(b'AZKXF1YB')
                        asyncio.create_task(flash_x())
                        stream = b'' 
                        message = b'' 
                        receiving_message = False
                        continue

                if len(message) == 4:
                    if message[3:4] not in team and message[3:4] != BROADCAST_ID:
                        print('ESP: receiver not in team')
                        uart.write(b'AZKXF2YB')
                        asyncio.create_task(flash_x())
                        stream = b'' 
                        message = b''
                        receiving_message = False
                        continue

                if len(message) > MAX_MESSAGE_LEN:
                    print('ESP: Message too long, aborting, prefix detected')
                    uart.write(b'AZKXF6YB')
                    asyncio.create_task(flash_x())
                    stream = b''
                    message = b''
                    receiving_message = False

                if message[-2:] == UART_SUFFIX:
                    print(f'ESP: Full message received: {message}')
                    asyncio.create_task(indicate_processing())
                    await handle_message(message)  # Process complete message
                    led.value(led.value() ^ 1)  
                    stream = b''
                    message = b''
                    receiving_message = False
                    continue

        await asyncio.sleep_ms(10)

async def process_mqtt_message(mqtt_msg):
    try:
        if len(mqtt_msg) == 3:
            mqtt_msg = bytearray(mqtt_msg)
            print(f"MQTT message: {mqtt_msg}")
            #uart.write(mqtt_msg)  

            if mqtt_msg == b"RST":  
                print("Master Reset Triggered")
                uart.write(b'AZKXR1YB')
                asyncio.create_task(indicate_processing())
                print(f"Sending message: AZKXR1YB")
                await client.publish(TOPIC_ERRORADDRESS, 'None') 
                await client.publish(TOPIC_ERRORCODE, 'None') 

            elif mqtt_msg == b"ERR":
                uart.write(b'AZKXF1YB')
                asyncio.create_task(indicate_processing())
                print("Sending Test Error Message: AZKXF1YB")
                
            else:
                print(f"Invalid MQTT command with Correct Message Length: {mqtt_msg}")
                uart.write(b'AZKXF8YB')
                asyncio.create_task(flash_x())
        else:
            print(f"Invalid MQTT message length: {len(mqtt_msg)}, expected 3 characters.")
            uart.write(b'AZKXF9YB')
            asyncio.create_task(flash_x())
            
    except Exception as e:
        print(f"Error processing MQTT message: {e}")
        uart.write('AZKXF0YB')
        asyncio.create_task(flash_x())

try:
    loop = asyncio.get_event_loop()
    loop.create_task(main(client))
    loop.run_forever()
finally:
    client.close()
    asyncio.new_event_loop()